#ifndef OV7725_H
#define OV7725_H

#include "main.h"
#include "camera.h"

int ov7725_init(framesize_t framesize);

#endif
