#ifndef __DRIVER_LCD_ILI9481_H
#define __DRIVER_LCD_ILI9481_H

#include "dev_lcd_conf.h"

void driver_LCD_ILI9481_init(LCDTypedef *lcd);

#endif