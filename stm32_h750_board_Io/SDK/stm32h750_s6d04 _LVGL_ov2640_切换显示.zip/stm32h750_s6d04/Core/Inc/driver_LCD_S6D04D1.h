#ifndef __DRIVER_LCD_S6D04D1_H
#define __DRIVER_LCD_S6D04D1_H

#include "dev_lcd_conf.h"

void driver_LCD_S6D04D1_init(LCDTypedef *lcd);


#endif