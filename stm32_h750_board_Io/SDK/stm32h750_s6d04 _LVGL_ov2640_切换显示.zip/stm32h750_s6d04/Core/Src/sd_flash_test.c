
#include "main.h"
#include "fatfs.h"
#include "quadspi.h"
#include "delay.h"
#include "driver_spi_flash.h"

/**
 * @brief   ��ȡFlash�ڲ���ID
 * @param   none
 * @retval    �ɹ�����device_id
 */
uint16_t QSPI_W25QXX_ReadID(void)
{
    uint8_t recv_buf[2] = {0};    //recv_buf[0]���Manufacture ID, recv_buf[1]���Device ID
    uint16_t device_id = 0;
    if(HAL_OK == QSPI_Send_Command(ManufactDeviceID_CMD, 0, 0, QSPI_INSTRUCTION_1_LINE, QSPI_ADDRESS_1_LINE, QSPI_ADDRESS_24_BITS, QSPI_DATA_1_LINE))
    {
        //��ȡID
        if(HAL_OK == QSPI_Receive(recv_buf, 2))
        {
            device_id = (recv_buf[0] << 8) | recv_buf[1];
						printf("\r\nstart:%x\r\n",device_id);
            return device_id;
        }
        else
        {
            return 0;
        }
    }
    else
    {
        return 0;
    }
}


// ������
#define WORK_BUFFER_SIZE  4096
static char work_buffer[WORK_BUFFER_SIZE];

uint8_t exf_getfree(uint8_t *drv,uint32_t *total,uint32_t *free)
{
    FATFS *fs1;
    uint8_t res;
    uint32_t fre_clust=0, fre_sect=0, tot_sect=0;
    res =(uint32_t)f_getfree((const TCHAR*)drv, (DWORD*)&fre_clust, &fs1);
    if(res==0)
    {
        tot_sect=(fs1->n_fatent-2)*fs1->csize;
        fre_sect=fre_clust*fs1->csize;
#if _MAX_SS!=512
        tot_sect*=fs1->ssize/512;
        fre_sect*=fs1->ssize/512;
#endif
        *total=tot_sect>>1;	//?��?KB
        *free=fre_sect>>1;	//?��?KB
    }
    return 0;
}


//   fatfs test
void sd_fatfs_test(void)
{
	    retSD = f_mount(&SDFatFS,SDPath, 0);
    if(retSD)
    {
        printf(" sdcard mount error : %d \r\n",retSD);
        // ���û�ļ�ϵͳ
        if(retSD == FR_NO_FILESYSTEM)
        {
            printf("f_mount no file system  begin mkfs sdcard\r\n");
            retSD = f_mkfs(SDPath,FM_ANY,0,work_buffer,WORK_BUFFER_SIZE);
            if(retSD != FR_OK)
            {
                printf("f_mkfs sdcard error,err = %d\r\n", retSD);
                while(1);
            }
            else
            {
                printf("f_mount sdcard ok \r\n");
                retSD = f_mount(&SDFatFS, SDPath, 0);
                if(retSD != FR_OK)
                {
                    printf("f_mount sdcard error,err = %d\r\n", retSD);
                }
                else {
                    printf("f_mount sdcard ok \r\n");
                }
            }
        }
        else
        {
            printf("f_mount sdcard ,err = %d\r\n", retSD);
            while(1);
        }
    }
    else {
        printf(" mount sdcard ok! \r\n");
    }
		
		uint32_t total,free;

    while(exf_getfree("0:",&total,&free))
    {
        delay_ms(200);
        printf("wait find sd size\r\n");
    }
    printf("spi flash total size:%d KB  %dMB, free size:%d KB   %dMB\r\n",total,total/1024,free,free/1024);
	  
		
}

FRESULT fr;
FIL     fd;

char filename[] = "0:test.txt";
uint8_t write_dat[] = "Hello,FATFS!\n";
uint16_t write_num = 0;

unsigned int count = 0;
unsigned char read_buf[50] = {0};

static void sdcard_fatfs_test(void)
{

    fr = f_open(&fd, filename, FA_CREATE_ALWAYS | FA_WRITE);
    if(fr == FR_OK)
    {
       
    }
    else
    {
        printf("open file error : %d\r\n",fr);
    }

    fr = f_write(&fd, write_dat, sizeof(write_dat), (void *)&write_num);
    if(fr == FR_OK)
    {
			printf("write data:%s \r\n",write_dat);
    }
    else
    {
        printf("write data error:%d\r\n",fr);
    }


    fr = f_close(&fd);
    if(fr == FR_OK)
    {
        
    }
    else
    {
			printf("close file error:%d.\r\n", fr);
    }
		
		
		retSD = f_open(&fd, filename, FA_OPEN_EXISTING | FA_READ);
    if(retSD == FR_OK)
    {
        retSD = f_read(&fd, read_buf, sizeof(read_buf), &count);
        if(retSD != FR_OK)
        {
					printf("read buf error: %d\r\n", retSD);
            f_close(&fd);
        }
        else
        {

            printf("read buf:%s\r\n", read_buf);
            f_close(&fd);
        }
    }
    else
    {
			printf("open error code:%d\r\n", retSD);
    }
		
}


void sd_qspi_test()
{
	uint16_t idx = QSPI_W25QXX_ReadID();
	
	 //drv_com1_printf("qspi flash id:%x\r\n",idx);

	driver_spi_flash_init();

	char ssx[10];
	sd_fatfs_test();
	sdcard_fatfs_test();
}

