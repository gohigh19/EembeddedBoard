## 1 LCD横竖坐标计算

![image-20210108195729881](readME.assets/image-20210108195729881.png)

正常的屏幕X和Y应该是这样的, 并且刷新方向都是从左往右, 从上到小

![image-20210108195837028](readME.assets/image-20210108195837028.png)

如果想要切换到横竖屏的状态

![image-20210108200104095](readME.assets/image-20210108200104095.png)

那么对应的坐标映射为:

![image-20210108200241992](readME.assets/image-20210108200241992.png)

x和Y发生了颠倒的情况

对应代码为

```
	// 竖屏
	if(g_mlcd->dir) {
		  mx = y;
		  my = LCD_PIX_HEIGHT - x -1;  // 注意要减掉1
	} else { // 横屏
		 mx = x;
		  my = y;
	}
```



## 对应窗口修改为

![image-20210108200907477](readME.assets/image-20210108200907477.png)

不能像下面一样计算这两个点, 这样是错误的

<img src="readME.assets/image-20210108201021446.png" alt="image-20210108201021446" style="zoom:50%;" />

要计算这两个点, 才是正确的, 无论横屏和竖屏都是计算这2个点

<img src="readME.assets/image-20210108201103628.png" alt="image-20210108201103628" style="zoom:50%;" />

对应坐标为: ex,sy   sx,ey

![image-20210108201158774](readME.assets/image-20210108201158774.png)

然后替换掉x和y 得到了

```
	    // 竖屏
   if(g_mlcd->dir) {
        // 原生分辨率
      msx = start_y;
			msy = LCD_PIX_HEIGHT - end_x -1;
			mex = end_y,
			mey = LCD_PIX_HEIGHT - start_x -1;
   } else { // 横屏
     msx =start_x;
		 msy =start_y;
		 mex =end_x;
		 mey =end_y;
   }
```

