[TOC]

## 1 ILI9481

寄存器0x36

在78页

<img src="readME.assets/image-20210108211443354.png" alt="image-20210108211443354" />

![image-20210108211458797](readME.assets/image-20210108211458797.png)

1 横向

0x28

2 纵向

0x0A

## 2 S6D04D1C

寄存器 0x36

关于RGB,BGR顺序和  像素点显示顺序在datasheet 262页

<img src="readME.assets/image-20210108201904005.png" alt="image-20210108201904005" style="zoom:50%;" />

1  横屏 0x60是把D6和D7设置为1, 方向为横屏显示, 具体的刷新方向如图, 这样是标准的横屏刷新方向

<img src="readME.assets/image-20210108202136536.png" alt="image-20210108202136536" style="zoom:50%;" />

2 竖屏0x00 是标准的竖屏

<img src="readME.assets/image-20210108202707027.png" alt="image-20210108202707027" style="zoom:50%;" />